var x =2;
var z =3;
var y =5;
console.log(x);
console.log(y);
console.log(z);
