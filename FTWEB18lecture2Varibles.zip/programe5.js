var name="sahil laged";
console.log(name);


father_name="bhaskar lagad";
console.log(father_name);

mother_name="pramila lagad";
console.log(mother_name)





