var a = 10 ;
var b = 20 ;
var c = 30 ;
var d = 40 ;
var e = 41 ;



console.log(b) ;
console.log(c) ;
console.log(d) ;
console.log(e) ;

