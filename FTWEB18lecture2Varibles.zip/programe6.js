var name_of_school="🎓🎓subhedar wada high school🎓🎓"
var name_of_student="sahil bhaskar lagad"
var roll_no=47
var grade="b"
var section="bcom"
var student_id=22769
var seat_no=2345
var annual_mark_sheet="🌟🌟🌟ANNUAL MARK SHEET🌟🌟🌟"
var marks_scored_in_english="78 out of 80"
var marks_scored_in_marathi="68 out of 80"
var marks_scored_in_economic="58 out of 80"
var marks_scored_in_book_keeping_and_accountancy="53 out of 80"
var marks_scored_in_secraterial_practice="61 out of 80"
var remark="GRADE 1"
var date=29/03/2021



console.log(name_of_school);
console.log(annual_mark_sheet)
console.log("Name Of Student:",name_of_student);
console.log("Roll_No:",roll_no);
console.log("Grade:",grade);
console.log("Section:",section);
console.log("Student Id:",student_id);
console.log("Seat No:",seat_no)
console.log("---------------------------------------------------")
console.log("Marks Scored In English:",marks_scored_in_english)
console.log("Marks Scored In Marathi:",marks_scored_in_marathi)
console.log("Marks Scored In Economic:",marks_scored_in_economic)
console.log("Marks Scored In Book Keeping And Accountancy:", marks_scored_in_book_keeping_and_accountancy)
console.log("Marks Scored In Secraterial Practice:",marks_scored_in_secraterial_practice)

console.log("-------------------------------🙏🙏🙏🙏🙏🙏🙏---------------------");

console.log("Remark:",remark)
console.log("Date:",date)
console.log("✉✍📅")
