var x=2,y=3,z=4
console.log(x,y,z);