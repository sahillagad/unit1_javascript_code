var x=2
var b=3
var name="sahil baskar lagad"

console.log(x+b)
console.log("Name:",name)
x=5
console.log(x)
console.log(x+b)
console.log("https://as1.ftcdn.net/v2/jpg/02/08/20/26/1000_F_208202630_Or6MqzZ7wAraQuLCgA23AocDygtzbfbp.jpg")