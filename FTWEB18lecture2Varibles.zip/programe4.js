var school="Masai School"


console.log("A Transformation in Education:",school);