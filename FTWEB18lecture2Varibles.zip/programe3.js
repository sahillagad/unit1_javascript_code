var name ="sahil bhaskar lagad "
var age = 21
var hobbies ="read books"
var favourite_food ="pav bhaji"
var school_name ="subhedar wada high school"
var shoe_size=9


console.log("Name:",name);
console.log("My Age Is:",age);
console.log("MY Hobbies Is:",hobbies)
console.log("My Favourite Food is:",favourite_food )
console.log("School Name:",school_name)
console.log("Shoe Size:",shoe_size)


