var x = 2
var y ="sahil"
var z ="96 movie"

console.log(y)
console.log(typeof"y")
console.log(typeof"z")
console.log(typeof(y))
